# <center>MD5优化算法选择器</center>

------

​								<center>编纂者：PB22081551  蓝欣妮</center>

功能：优化算法任君选择（可多选组合），实现对输入文本的摘要生成。

用法：

1. 进入"MD5_Project"，双击MD5_encrypt_user.exe后出现以下界面：

<img src="C:\Users\ROG\AppData\Roaming\Typora\typora-user-images\image-20240609021850804.png" alt="image-20240609021850804" style="zoom:67%;" />

2. 根据提示输入消息文本（暂不支持中文输入），可换行；

3. 选择MD5算法优化方式（可多选），如不选择默认由未优化的MD5进行摘要生成；

4. 点击输出消息摘要，得到结果。示例如下：

   <img src="C:\Users\ROG\AppData\Roaming\Typora\typora-user-images\image-20240609022100270.png" alt="image-20240609022100270" style="zoom:67%;" />